
//------------------------------------------ FOR FIDELITY PRODUCTION -------------------------------//
import { AngularEditorConfig } from '@kolkov/angular-editor';

export const config = {
  // apiurl3: 'https://win.k2key.in/ohcampus/admin//',
apiurl3: 'https://win.k2key.in/ohcampus/admin/',
apiurl4:'https://win.k2key.in/ohcampus/web/'


// apiurl3: 'https://campus.api.com/admin/',
// apiurl4:'https://campus.api.com/web/'


  // encKey : "202019$#@$^@1fed",
  // server_name: "https://api.fidelityunited.ae/index.php/",
  // logOutURL : 'https://portal.fidelityunited.ae/logout.aspx',
  // motor_hire_purchase_clause : "https://iirisgidoc.fidelityunited.ae/DocumentPrint/GID035.aspx?pEndtSrlNo=0&pUserLang=ENG&pLogo=Y&pOutType=pdf&pPolUid=",
  // autologouttime:15,
  // planBenefitID :  477  //For Roadside Assistance - Bronze .

};



