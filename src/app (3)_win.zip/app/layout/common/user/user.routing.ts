import { Route } from '@angular/router';
import { UserComponent } from './user.component';

export const user1Routes: Route[] = [
    {
        path     : 'user1',
        component: UserComponent
    }
];