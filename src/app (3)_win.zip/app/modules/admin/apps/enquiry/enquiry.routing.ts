import { Route } from '@angular/router';
import { EnquirylistComponent } from './enquirylist/enquirylist.component';

export const enquiryRoutes: Route[] = [
   
    {
        path     : 'enquirylist',
        component: EnquirylistComponent,
    },
    
   
   
]