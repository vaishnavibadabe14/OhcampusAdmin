import { Route } from '@angular/router';
import { CourseenquirylistComponent } from './courseenquirylist/courseenquirylist.component';

export const coenquiryRoutes: Route[] = [
   
    {
        path     : 'courseenquirylist',
        component: CourseenquirylistComponent,
    },
   
   
]