import { Route } from '@angular/router';
import { QuestionsanslistComponent } from './questionsanslist/questionsanslist.component';

export const questionandansRoutes: Route[] = [

    {
        path     : 'questionandanslist',
        component: QuestionsanslistComponent,
    },



]
