import { Component, OnInit,ViewChild ,TemplateRef, Input, EventEmitter, Output} from '@angular/core';
import { FormBuilder, FormGroup, Validators,NgForm } from '@angular/forms';
import { CampusService } from 'app/modules/service/campus.service'
import { GlobalService } from 'app/modules/service/global.service';
import { MatDialog } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-coarses',
  templateUrl: './coarses.component.html',
  styleUrls: ['./coarses.component.scss']
})

export class CoarsesComponent implements OnInit {
  @Output() valueChanged: EventEmitter<string> = new EventEmitter<string>();
  @Input() collegeDetails: any;
  @Input() course_data: any;
  coursesForm : FormGroup;
  showLoader: boolean = false;
  addLoader: boolean = false;
  updateLoader : boolean = false;
  updateButton : boolean = false;
  Loader : boolean = false;
  retriveData: any;

  UGCourseslist: any[] = [];
  PGCourseslist: any[] = [];
  DiplomaCourseslist: any[] = [];
  DoctorialCourseslist: any[] = [];
  OtherCourseslist: any[] = [];
  postCourseslist: any[] = [];
  advMasteCourseslist: any[] = [];

  selectedUGCourses: any[] = [];
  selectedPGCourses:  any[] = [];
  selectedDiplomaCourses:  any[] = [];
  selectedDoctorialCourses:  any[] = [];
  selectedOherCourses:  any[] = [];
  selectedPostDocrCourses:  any[] = [];
  selectedAdvMasterrCourses:  any[] = [];

  clgId: any;


  constructor(
    private _formBuilder: FormBuilder,
    private campusService : CampusService,
    public globalService: GlobalService,
    public dialog: MatDialog,
    public _activatedroute: ActivatedRoute,
    public _route: Router, ) { }

  ngOnInit(): void {
    this.coursesForm = this._formBuilder.group({
      ugcourse:[''],
      searchUg:[''],
      pgcourse:[''],
      searchPg:[''],
      diplomacourse:[''],
      searchDp:[''],
      doctorialcourse:[''],
      searchDoc:[''],
      postdoctorialcourse:[''],
      searcPostDoc:[''],
      advancedmastercourse:[''],
      searcAdvMas:[''],
      othercourse:[''],
      searchOther:['']

})
    this.getUGCourses()
    this.getPGCourses()
    this.getDiplomaCourse();
    this.getDoctorialCourses();
    this.getPostDocCourses();
    this.getAdvMasterCourses();
    this.getOtherCourses();

    this.clgId = this.collegeDetails.id

    if ((this.clgId != null)) {
      this.Loader = true
      setTimeout(() => {
      this.bindUgCourses()
      this.bindPgCourses()
      this.bindDiplomaCourses()
      this.bindDoctorialCourses()
      this.bindPostDoctorialCourses()
      this.bindAdvMasterCourses()
      this.bindOtherCourses()
    }, 1500);
    }
  }

  ngAfterViewInit(): void {
    if ((this.clgId != null)) {
      this.updateButton = true
    }
  }

  viewCourse(courseId){
    this._route.navigate(['apps/courseDetails/viewcourse/'+ courseId +'/'+this.clgId ]);
  }

// ---------------------------------UG Courses---------------------------------//

getUGCourses(){
    this.campusService.getUGCourses(this.coursesForm.value.searchUg).subscribe((res) =>{
    this.UGCourseslist = res.response_data

  })
}

bindUgCourses(){
  if(this.UGCourseslist != undefined){
  this.course_data.forEach((item) => {
    this.UGCourseslist.forEach((itemm) => {
    if (item.courseid == itemm.id) {
      this.selectedUGCourses.push(itemm);
      this.changeUGSelection;
    }
  });
  this.coursesForm.get('ugcourse').setValue(this.selectedUGCourses);
        this.changeUGSelection(this.coursesForm.value.ugcourse);
})
  }
this.Loader = false
}

changeUGSelection(selectedCourses: any) {
  this.selectedUGCourses = selectedCourses;
  console.log( this.selectedUGCourses)
}

removeUgCourse(index: number, id: any) {
    if (id != null) {
      this.selectedUGCourses = this.selectedUGCourses.filter(item => item.id !== id);
      const ugCoursesControl = this.coursesForm.get('ugcourse');
      if (ugCoursesControl) {
        ugCoursesControl.setValue(this.selectedUGCourses);
      }
    }
}

// ---------------------------------PG Courses---------------------------------//

getPGCourses(){
  this.campusService.getPGCourses(this.coursesForm.value.searchPg).subscribe((res) =>{
    this.PGCourseslist = res.response_data
})
}

bindPgCourses(){
  if(this.PGCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.PGCourseslist.forEach((itemm) => {
        if (item.courseid == itemm.id) {
        this.selectedPGCourses.push(itemm);
        this.changePGSelection;
      }
    });
    this.coursesForm.get('pgcourse').setValue(this.selectedPGCourses);
    this.changePGSelection(this.coursesForm.value.pgcourse);
  })
}
  this.Loader = false
}

changePGSelection(selectedCourses: any[]) {
  this.selectedPGCourses = selectedCourses;
}

removePGCourse(index: number, id: any) {
    if (id != null) {
      this.selectedPGCourses = this.selectedPGCourses.filter(item => item.id !== id);
      const pgCoursesControl = this.coursesForm.get('pgcourse');
      if (pgCoursesControl) {
        pgCoursesControl.setValue(this.selectedPGCourses);
      }
    }
}

// ---------------------------------Diploma Courses---------------------------------//

getDiplomaCourse(){
  this.campusService.getDiplomaCourses(this.coursesForm.value.searchDp).subscribe((res) =>{
    this.DiplomaCourseslist = res.response_data

})
}

bindDiplomaCourses(){
  if(this.DiplomaCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.DiplomaCourseslist.forEach((itemm) => {

        if (item.courseid === itemm.id) {
        this.selectedDiplomaCourses.push(itemm);
        this.changeDiplomaSelection;

      }
    });
    this.coursesForm.get('diplomacourse').setValue(this.selectedDiplomaCourses);
    this.changeDiplomaSelection(this.coursesForm.value.diplomacourse);
  })
}
  this.Loader = false
}

changeDiplomaSelection(selectedCourses: any[]) {
  this.selectedDiplomaCourses = selectedCourses;
}

removeDiplomaCourse(index: number, id: any) {
    if (id != null) {
      this.selectedDiplomaCourses = this.selectedDiplomaCourses.filter(item => item.id !== id);
      const diplomaCoursesControl = this.coursesForm.get('diplomacourse');
      if (diplomaCoursesControl) {
        diplomaCoursesControl.setValue(this.selectedDiplomaCourses);
      }
    }
}

// ---------------------------------Doctorial Courses---------------------------------//

getDoctorialCourses(){
  this.campusService.getDoctorialCourses(this.coursesForm.value.searchDoc).subscribe((res) =>{
    this.DoctorialCourseslist = res.response_data

})
}

changeDoctorialSelection(selectedCourses: any[]) {
  this.selectedDoctorialCourses = selectedCourses;
}

bindDoctorialCourses(){
  if(this.DoctorialCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.DoctorialCourseslist.forEach((itemm) => {

        if (item.courseid === itemm.id) {
        this.selectedDoctorialCourses.push(itemm);
        this.changeDoctorialSelection;

      }
    });
    this.coursesForm.get('doctorialcourse').setValue(this.selectedDoctorialCourses);
    this.changeDoctorialSelection(this.coursesForm.value.doctorialcourse);
  })
}
  this.Loader = false
}

removeDoctorialCourses(index: number, id: any) {
  if (id != null) {
    this.selectedDoctorialCourses = this.selectedDoctorialCourses.filter(item => item.id !== id);
    const doctorialCoursesControl = this.coursesForm.get('doctorialcourse');
    if (doctorialCoursesControl) {
      doctorialCoursesControl.setValue(this.selectedDoctorialCourses);
    }
  }
}

// ---------------------------------Post Doctorial Courses---------------------------------//

getPostDocCourses(){
  this.campusService.getPostDocCourses(this.coursesForm.value.searcPostDoc).subscribe((res) =>{
    this.postCourseslist = res.response_data

})
}

changePostDocrSelection(selectedCourses: any[]) {
  this.selectedPostDocrCourses = selectedCourses;
}

bindPostDoctorialCourses(){
  if(this.postCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.postCourseslist.forEach((itemm) => {
        if (item.courseid === itemm.id) {
        this.selectedPostDocrCourses.push(itemm);
        this.changePostDocrSelection;
      }
    });
    this.coursesForm.get('postdoctorialcourse').setValue(this.selectedPostDocrCourses);
    this.changePostDocrSelection(this.coursesForm.value.postdoctorialcourse);
  })
}
  this.Loader = false
}

removePostDoctrialCourse(index: number, id: any) {
    if (id != null) {
      this.selectedPostDocrCourses = this.selectedPostDocrCourses.filter(item => item.id !== id);
      const postdoctCoursesControl = this.coursesForm.get('postdoctorialcourse');
      if (postdoctCoursesControl) {
        postdoctCoursesControl.setValue(this.selectedPostDocrCourses);
      }
    }
}

// ---------------------------------Adv Master Courses---------------------------------//

getAdvMasterCourses(){
  this.campusService.getAdvMasterCourses(this.coursesForm.value.searcAdvMas).subscribe((res) =>{
    this.advMasteCourseslist = res.response_data
})
}

changeAdvMasterSelection(selectedCourses: any[]) {
  this.selectedAdvMasterrCourses = selectedCourses;
}

bindAdvMasterCourses(){
  if(this.advMasteCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.advMasteCourseslist.forEach((itemm) => {

        if (item.courseid === itemm.id) {
        this.selectedAdvMasterrCourses.push(itemm);
        this.changeAdvMasterSelection;

      }
    });
    this.coursesForm.get('advancedmastercourse').setValue(this.selectedAdvMasterrCourses);
    this.changeAdvMasterSelection(this.coursesForm.value.advancedmastercourse);
  })
}
  this.Loader = false
}

removeAdvMasterCourses(index: number, id: any) {
    if (id != null) {
      this.selectedAdvMasterrCourses = this.selectedAdvMasterrCourses.filter(item => item.id !== id);
      const dAdvMasterCoursesControl = this.coursesForm.get('advancedmastercourse');
      if (dAdvMasterCoursesControl) {
        dAdvMasterCoursesControl.setValue(this.selectedAdvMasterrCourses);
      }
    }
}

// ---------------------------------Other Courses---------------------------------//

getOtherCourses(){
  this.campusService.getOtherCourses(this.coursesForm.value.searchOther).subscribe((res) =>{
    this.OtherCourseslist = res.response_data
})
}

bindOtherCourses(){
  if(this.OtherCourseslist != undefined){
    this.course_data.forEach((item) => {
      this.OtherCourseslist.forEach((itemm) => {

        if (item.courseid === itemm.id) {
        this.selectedOherCourses.push(itemm);
        this.changeOtherSelection;

      }
    });
    this.coursesForm.get('othercourse').setValue(this.selectedOherCourses);
    this.changeOtherSelection(this.coursesForm.value.othercourse);
  })
}
  this.Loader = false
}

changeOtherSelection(selectedCourses: any[]) {
  this.selectedOherCourses = selectedCourses;
}

removeOtherCourses(index: number, id: any) {
    if (id != null) {
      this.selectedOherCourses = this.selectedOherCourses.filter(item => item.id !== id);
      const selectedOherControl = this.coursesForm.get('othercourse');
      if (selectedOherControl) {
        selectedOherControl.setValue(this.selectedOherCourses);
      }
    }
}

 insertCourseForClg(){
    this.updateLoader = true
    this.clgId = this.collegeDetails.id

    let courses = this.selectedUGCourses.concat(this.selectedPGCourses);
    this.campusService.updateCourseForClg(this.clgId,courses).subscribe((res) =>{
      if(res.response_message == "Success"){
        this.updateLoader = false
        Swal.fire({
          text: 'College courses added successful',
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: "#3290d6 !important",
          confirmButtonText: 'Ok'
        }).then((result) => {
          if (result.isConfirmed) {
            this.sendValueToParent()
          }
        });
      }else{
        this.updateLoader = false
        Swal.fire('', res.response_message , 'error')
      }

    })
  }

  updateCourseForClg(){

    this.clgId = this.collegeDetails.id

    this.updateLoader = true
    let courses = this.selectedUGCourses.concat(this.selectedPGCourses).concat(this.selectedDiplomaCourses).concat(this.selectedDoctorialCourses).concat(this.selectedOherCourses).concat(this.selectedPostDocrCourses).concat(this.selectedAdvMasterrCourses);
    this.campusService.updateCourseForClg(this.clgId,courses).subscribe((res) =>{
      if(res.response_message == "Success"){
        this.updateLoader = false
        Swal.fire({
          text: 'College courses updated successful',
          icon: 'success',
          showCancelButton: false,
          confirmButtonColor: "#3290d6 !important",
          confirmButtonText: 'Ok'
        }).then((result) => {
          if (result.isConfirmed) {
            this.sendValueToParent()
          }
        });
      }else{
        this.updateLoader = false
        Swal.fire('', res.response_message , 'error')
      }

    })
  }

  back(){
    this.sendValueToParent2();
  }

  sendValueToParent() {
    const valueToSend = "4";
    this.valueChanged.emit(valueToSend);
  }

  sendValueToParent2() {
    const valueToSend = "2";
    this.valueChanged.emit(valueToSend);
  }
}

